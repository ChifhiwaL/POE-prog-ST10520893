# QuickChat Part 3 – corrected project

This is a Java 17+ console implementation of the QuickChat workflow shown in the supplied Part 3 demonstration.

## Requirements
- JDK 17 or later
- Apache Ant 1.10 or later (optional if you compile with `javac`)

## Build and test in Windows CMD
Open CMD in the folder containing `build.xml`, then run:

```bat
java -version
ant -version
ant clean test jar
java -jar dist\QuickChatPart3.jar
```

The `test` target runs seven dependency-free smoke tests. The runnable JAR is created at `dist\QuickChatPart3.jar`.

## Features
- Registration validation for names, username, password and South African international cellphone number
- Login with retry after incorrect credentials
- Main menu for sending a batch, viewing sent messages, quitting and opening Stored Messages
- 1–250 character message validation, recipient validation, ten-digit message IDs and message hashes
- Send, disregard and store actions
- Stored-message submenu options 1–8: sender/recipient report, longest stored message, ID lookup across all message groups, stored-recipient search, deletion by full hash, full stored report, combined sent/stored recipient search, and return
- JSON persistence in `messages.json`; stored messages are reloaded when the program starts

## Notes
- `messages.json` is created in the current working directory when the first message is stored. Keep running the JAR from the same folder to reuse the archive.
- Sent and disregarded messages are session-only, while stored messages persist in JSON, matching the supplied demonstration.
- The cellphone number entered during registration is used as the sender number in message reports.
- This ZIP contains the corrected implementation and a lightweight smoke-test suite. It does not contain the original assessment brief, so compare class/method naming and any rubric-specific wording against the official brief before submission.
