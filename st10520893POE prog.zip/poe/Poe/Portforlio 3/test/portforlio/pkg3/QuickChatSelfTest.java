package portforlio.pkg3;

/** Dependency-free smoke tests; run with the Ant test target. */
public class QuickChatSelfTest {
    public static void main(String[] args) {
        check(Message.validRecipient("+27834557896"), "international SA mobile accepted");
        check(Message.validRecipient("0838884567"), "local SA mobile accepted");
        check(!Message.validRecipient("12345"), "invalid recipient rejected");
        check(!Message.validRecipient("+27123456789"), "invalid mobile prefix rejected");
        Message m = new Message("Did you get the cake?", "+27834557896", 1, "Sent");
        check(m.getId().matches("\\d{10}"), "message ID has ten digits");
        check(m.getMessageHash().matches("\\d{2}:1:DIDCAKE\\?"), "message hash uses prefix, number and first/last words");
        check(m.getContent().length() <= 250, "sample message within the 250-character limit");
        System.out.println("All 7 QuickChat smoke tests passed.");
    }
    private static void check(boolean condition, String description) {
        if (!condition) throw new AssertionError("FAILED: " + description);
    }
}
