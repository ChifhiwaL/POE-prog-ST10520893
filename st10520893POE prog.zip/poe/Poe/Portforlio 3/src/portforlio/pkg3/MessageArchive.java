package portforlio.pkg3;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** Small dependency-free JSON archive for stored QuickChat messages. */
public final class MessageArchive {
    private static final Path FILE = Paths.get("messages.json");
    private MessageArchive() {}
    public static List<Message> load() throws IOException {
        if (!Files.exists(FILE)) return new ArrayList<>();
        String json = Files.readString(FILE, StandardCharsets.UTF_8);
        Object parsed = new Json(json).parse();
        if (!(parsed instanceof Map)) throw new IOException("The messages.json root must be an object.");
        Object rows = ((Map<?,?>) parsed).get("storedMessages");
        if (rows == null) rows = ((Map<?,?>) parsed).get("Stored_Messages");
        List<Message> result = new ArrayList<>();
        if (rows instanceof List) for (Object row : (List<?>) rows) {
            if (!(row instanceof Map)) continue;
            Map<?,?> m=(Map<?,?>)row;
            result.add(new ArchivedMessage(str(m,"content"),str(m,"recipient"),(str(m,"id").isEmpty()?str(m,"messageID"):str(m,"id")),(str(m,"hash").isEmpty()?str(m,"messageHash"):str(m,"hash")),str(m,"timestamp"),integer(m,"number")));
        }
        return result;
    }
    public static void save(List<Message> messages) throws IOException {
        StringBuilder b=new StringBuilder("{\n  \"storedMessages\": [");
        for(int i=0;i<messages.size();i++){
            Message m=messages.get(i); if(i>0)b.append(',');
            b.append("\n    {\"id\":\"").append(esc(m.getId())).append("\",\"hash\":\"").append(esc(m.getMessageHash()))
             .append("\",\"recipient\":\"").append(esc(m.getRecipient())).append("\",\"content\":\"").append(esc(m.getContent()))
             .append("\",\"timestamp\":\"").append(esc(m.getTimestamp())).append("\",\"number\":").append(m.getNumber()).append('}');
        }
        b.append("\n  ],\n  \"exportedAt\": \"").append(esc(java.time.LocalDateTime.now().toString())).append("\"\n}\n");
        Files.writeString(FILE,b.toString(),StandardCharsets.UTF_8);
    }
    private static String esc(String s){return s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","\\r").replace("\t","\\t");}
    private static String str(Map<?,?> m,String k){Object v=m.get(k);return v==null?"":v.toString();}
    private static int integer(Map<?,?>m,String k){try{return Integer.parseInt(str(m,k));}catch(Exception e){return 1;}}
    private static final class ArchivedMessage extends Message {
        ArchivedMessage(String c,String r,String id,String hash,String ts,int n){super(c,r,n,"Stored");this.idOverride=id;this.hashOverride=hash;this.tsOverride=ts;}
        private final String idOverride,hashOverride,tsOverride;
        @Override public String getId(){return idOverride;} @Override public String getMessageHash(){return hashOverride;} @Override public String getTimestamp(){return tsOverride;}
    }
    // Minimal JSON parser supporting objects, arrays, strings, numbers, booleans and null.
    private static final class Json {
        final String s; int p=0; Json(String s){this.s=s;}
        Object parse() throws IOException {Object v=value(); ws(); if(p!=s.length())throw err(); return v;}
        Object value() throws IOException {ws(); if(p>=s.length())throw err(); char c=s.charAt(p);
            if(c=='{')return object(); if(c=='[')return array(); if(c=='"')return string();
            int st=p; while(p<s.length() && ",]} \r\n\t".indexOf(s.charAt(p))<0)p++; String t=s.substring(st,p);
            if(t.equals("true"))return true;if(t.equals("false"))return false;if(t.equals("null"))return null;
            try{return Double.valueOf(t);}catch(Exception e){throw err();}}
        Map<String,Object> object() throws IOException {p++;Map<String,Object>m=new LinkedHashMap<>();ws();if(take('}'))return m;do{ws();if(p>=s.length()||s.charAt(p)!='"')throw err();String k=string();ws();if(!take(':'))throw err();m.put(k,value());ws();if(take('}'))return m;}while(take(','));throw err();}
        List<Object> array() throws IOException {p++;List<Object>a=new ArrayList<>();ws();if(take(']'))return a;do{a.add(value());ws();if(take(']'))return a;}while(take(','));throw err();}
        String string() throws IOException {p++;StringBuilder b=new StringBuilder();while(p<s.length()){char c=s.charAt(p++);if(c=='"')return b.toString();if(c=='\\'){if(p>=s.length())throw err();char e=s.charAt(p++);switch(e){case '"':case '\\':case '/':b.append(e);break;case 'n':b.append('\n');break;case 'r':b.append('\r');break;case 't':b.append('\t');break;case 'b':b.append('\b');break;case 'f':b.append('\f');break;case 'u':if(p+4>s.length())throw err();b.append((char)Integer.parseInt(s.substring(p,p+4),16));p+=4;break;default:throw err();}}else b.append(c);}throw err();}
        void ws(){while(p<s.length()&&Character.isWhitespace(s.charAt(p)))p++;} boolean take(char c){if(p<s.length()&&s.charAt(p)==c){p++;return true;}return false;} IOException err(){return new IOException("Invalid JSON near character "+p);}
    }
}
