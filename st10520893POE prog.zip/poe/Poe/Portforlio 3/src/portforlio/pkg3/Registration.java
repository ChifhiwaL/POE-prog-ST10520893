package portforlio.pkg3;
import java.util.Scanner;
public class Registration {
    public static void main(String[] args){new Registration().startRegistration();}
    public void startRegistration(){Scanner in=new Scanner(System.in);System.out.println("===== USER REGISTRATION =====");
        String first=nonEmpty(in,"Enter your first name: "),last=nonEmpty(in,"Enter your surname: ");
        String user;do{System.out.print("Enter your username: ");user=in.nextLine().trim();if(user.length()>5||!user.contains("_"))System.out.println("Username must contain an underscore and be no more than five characters.");}while(user.length()>5||!user.contains("_"));
        String pass;do{System.out.print("Enter your password: ");pass=in.nextLine();if(!pass.matches("(?=.*[A-Z])(?=.*\\d)(?=.*[^A-Za-z0-9]).{8,}"))System.out.println("Password must be at least eight characters and contain a capital letter, a number and a special character.");}while(!pass.matches("(?=.*[A-Z])(?=.*\\d)(?=.*[^A-Za-z0-9]).{8,}"));
        String phone;do{System.out.print("Enter your cellphone number (e.g. +27839868976): ");phone=in.nextLine().trim();if(!phone.matches("\\+27[678]\\d{8}"))System.out.println("Enter a valid South African international mobile number starting +27.");}while(!phone.matches("\\+27[678]\\d{8}"));
        System.out.println("Registration successful!\n");Login login=new Login();login.registerUser(user,pass,first,last);if(login.loginUser(in))new Loggedin(login.getUsername(),login.getFullName(),phone,in).Choice();
    }
    private String nonEmpty(Scanner in,String prompt){String s;do{System.out.print(prompt);s=in.nextLine().trim();if(s.isEmpty())System.out.println("This field cannot be empty.");}while(s.isEmpty());return s;}
}
