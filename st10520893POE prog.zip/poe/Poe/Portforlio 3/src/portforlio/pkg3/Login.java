package portforlio.pkg3;
public class Login {
    private String username,password,firstName,lastName;
    public void registerUser(String u,String p,String f,String l){username=u;password=p;firstName=f;lastName=l;}
    public boolean loginUser(java.util.Scanner in){
        while(true){System.out.println("\n===== LOGIN =====");System.out.print("Enter your username: ");String u=in.nextLine().trim();System.out.print("Enter your password: ");String p=in.nextLine();
            if(u.equals(username)&&p.equals(password)){System.out.println("Welcome "+firstName+", "+lastName+" it is great to see you again.\n");return true;}
            System.out.println("Username or password incorrect, please try again.");
        }
    }
    public String getFullName(){return firstName+" "+lastName;} public String getUsername(){return username;}
}
