package portforlio.pkg3;

import java.time.LocalDateTime;
import java.util.concurrent.ThreadLocalRandom;

public class Message {
    private final String recipient, content, id, hash, timestamp;
    private final int number;
    private final String status;

    public Message(String content, String recipient, int number, String status) {
        this.content = content.trim(); this.recipient = recipient.trim(); this.number = number;
        this.timestamp = LocalDateTime.now().toString();
        this.id = String.format("%010d", ThreadLocalRandom.current().nextLong(1_000_000_000L, 10_000_000_000L));
        this.hash = makeHash(this.id, this.number, this.content);
        this.status = status;
    }
    public Message(String content, String recipient) { this(content, recipient, 1, "Stored"); }
    private static String makeHash(String id, int number, String content) {
        String[] words = content.trim().split("\\s+");
        String first = words[0], last = words[words.length - 1];
        return (id.substring(0, 2) + ":" + number + ":" + first + last).toUpperCase();
    }
    public static boolean validRecipient(String value) {
        return value != null && (value.matches("\\+27[678]\\d{8}") || value.matches("0[678]\\d{8}"));
    }
    public String getRecipient(){return recipient;} public String getContent(){return content;}
    public String getId(){return id;} public String getMessageHash(){return hash;}
    public String getTimestamp(){return timestamp;} public int getNumber(){return number;} public String getStatus(){return status;}
}
